import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


df = pd.read_csv("ANNONCES_CLEAN.csv")
os.makedirs("figures", exist_ok=True)

# --------------------------------------------------
# 1. Partie 1 : On séléctionne seulement les appartements 
# --------------------------------------------------
df_appart = df[df["type_bien"].str.contains("appart", case=False, na=False)]

print("Nombre total d'annonces :", len(df))
print("Nombre d'appartements :", len(df_appart))
print("Nombre de villes :", df_appart["ville"].nunique())

print("\n===== NOMBRE D'APPARTEMENTS PAR VILLE =====")
print(df_appart["ville"].value_counts())

# --------------------------------------------------
# 2. Partie 2 : Calcul moyenne & médiane du prix au m²
# --------------------------------------------------
moyenne_m2 = df_appart["prix_m2"].mean()
mediane_m2 = df_appart["prix_m2"].median()

print("\n===== STATISTIQUES PRIX AU M² (Appartements) =====")
print(f"Prix moyen au m² : {moyenne_m2:.0f} €")
print(f"Prix médian au m² : {mediane_m2:.0f} €")

# --------------------------------------------------
# 3. Partie 3 : Répartition des prix selon les villes 
# --------------------------------------------------
prix_ville = df_appart.groupby("ville")["prix"].mean().sort_values(ascending=False)

print("\n===== PRIX MOYEN PAR VILLE (Appartements) =====")
print(prix_ville.head(42))

plt.figure(figsize=(12, 8))
sns.barplot(x=prix_ville.head(42).values, y=prix_ville.head(42).index)
plt.title("Prix moyen des appartements par ville")
plt.xlabel("Prix moyen (€)")
plt.ylabel("Ville")
plt.tight_layout()
plt.savefig("figures/prix_moyen_par_ville.png", dpi=300, bbox_inches='tight')
plt.show()

# --------------------------------------------------
# 4. Partie 4 : Corrélation entre surface et prix
# --------------------------------------------------
corr = df_appart["surface"].corr(df_appart["prix"])
print("\n===== CORRÉLATION =====")
print(f"Corrélation surface/prix : {corr:.3f}")

plt.figure(figsize=(8, 6))
sns.scatterplot(x="surface", y="prix", data=df_appart)
plt.xlim(0, 200)
plt.ylim(0, 2000000)
plt.title("Corrélation entre surface et prix")
plt.xlabel("Surface (m²)")
plt.ylabel("Prix (€)")
plt.tight_layout()
plt.savefig("figures/correlation_surface_prix.png", dpi=300, bbox_inches='tight')
plt.show()

# --------------------------------------------------
# 5. Partie 5 : Histogrammes et Boxplots
# --------------------------------------------------

# 5.1 Histogramme général du prix au m² par ville
plt.figure(figsize=(16, 8))
sns.histplot(df["prix_m2"], bins=60, kde=True)
plt.xlim(500, 20000)   # limite réaliste du marché
plt.title("Distribution générale du prix au m²")
plt.xlabel("Prix au m² (€)")
plt.ylabel("Nombre d'annonces")
plt.tight_layout()
plt.savefig("figures/histogramme_prix_m2.png", dpi=300, bbox_inches='tight')
plt.show()

# 5.2 Boxplot du prix au m² par ville
plt.figure(figsize=(24, 18))  
sns.boxplot(
    data=df_appart,
    y="ville",
    x="prix_m2",
    order=sorted(df_appart["ville"].unique()))
plt.title("Boxplot du prix/m² par ville")
plt.xlabel("Prix/m² (€)")
plt.ylabel("Villes")
plt.tight_layout()
plt.savefig("figures/boxplot_prix_m2.png", dpi=300, bbox_inches='tight')
plt.show()

# 5.3 Les 10 villes les plus chères
villes_cheres = df_appart.groupby("ville")["prix_m2"].median().sort_values(ascending=False).head(10).index

plt.figure(figsize=(14, 8))
sns.boxplot(x="ville", y="prix_m2", data=df_appart[df_appart["ville"].isin(villes_cheres)])
plt.xticks(rotation=45)
plt.title("10 villes les plus chères")
plt.tight_layout()
plt.savefig("figures/boxplot_10_villes_cheres.png", dpi=300, bbox_inches='tight')
plt.show()

# 5.4 Barplot vertical complet du prix moyen au m² par ville
prix_par_ville = df_appart.groupby("ville")["prix_m2"].mean().sort_values()

plt.figure(figsize=(12, 22))
sns.barplot(x=prix_par_ville.values, y=prix_par_ville.index)
plt.title("Prix moyen au m² par ville")
plt.xlabel("Prix moyen au m² (€)")
plt.ylabel("Ville")
plt.tight_layout()
plt.savefig("figures/barplot_prix_moyen_au_m2.png", dpi=300, bbox_inches='tight')
plt.show()

# 5.5 Pairplot des variables numériques
df_pair = df_appart[["prix", "surface", "prix_m2", "pieces"]].dropna()

df_pair = df_pair.sample(min(len(df_pair), 400), random_state=1)

sns.pairplot(df_pair, diag_kind="kde", corner=True)
plt.suptitle("Pairplot – Relations entre variables", y=1.02)
plt.savefig("figures/pairplot_variables.png", dpi=300, bbox_inches='tight')
plt.show()

# --------------------------------------------------
print("\nAnalyse des appartements terminée !")

